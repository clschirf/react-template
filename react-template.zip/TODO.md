[X] get prettier working
[X] get babel & ts working
[X] get build working
[X] get build working w/ react
[X] get eslint working
[ ] figure out tslib stuff
[ ] get jest/testing working
[ ] add husky for precommit hooks
