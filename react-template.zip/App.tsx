const App = (): JSX.Element => {
  return <div>Main App</div>;
};

App.displayName = 'App';
export default App;
